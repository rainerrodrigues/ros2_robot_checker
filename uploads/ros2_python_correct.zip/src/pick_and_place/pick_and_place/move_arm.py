import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from builtin_interfaces.msg import Duration


class MoveArm(Node):
    def __init__(self):
        super().__init__('move_arm_node')
        self.publisher_ = self.create_publisher(
            JointTrajectory,
            '/scaled_joint_trajectory_controller/joint_trajectory',
            10
        )
        self.timer = self.create_timer(2.0, self.timer_callback)

    def timer_callback(self):
        msg = JointTrajectory()
        # 2. MUST match the exact joint names of your UR5 URDF
        msg.joint_names = [
            'shoulder_pan_joint', 'shoulder_lift_joint', 'elbow_joint',
            'wrist_1_joint', 'wrist_2_joint', 'wrist_3_joint'
        ]

        # 3. Create a trajectory point
        point = JointTrajectoryPoint()
        point.positions = [0.0, -1.0, 1.0, -1.0, -1.5, 0.0]
        point.time_from_start = Duration(sec=2, nanosec=0)
        msg.points.append(point)
        self.publisher_.publish(msg)
        self.get_logger().info('Sending Trajectory command to UR5...')


def main(args=None):
    rclpy.init(args=args)
    node = MoveArm()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
