import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState


class MoveArm(Node):
    def __init__(self):
        super().__init__('move_arm_node')
        # Two spaces before this comment to fix E261
        self.publisher_ = self.create_publisher(
            JointState, '/joint_commands', 10)  # Broken line to fix E501
        self.timer = self.create_timer(1.0, self.timer_callback)

    def timer_callback(self):
        msg = JointState()
        msg.name = ['joint1', 'joint2']
        msg.position = [0.5, -0.5]
        self.publisher_.publish(msg)
        self.get_logger().info('Moving Arm...')


def main(args=None):
    rclpy.init(args=args)
    node = MoveArm()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
    rclpy.shutdown()
