#include <ros/ros.h>
#include <sensor_msgs/JointState.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "move_arm_node");
    ros::NodeHandle nh;
    ros::Publisher pub = nh.advertise<sensor_msgs::JointState>("/joint_states", 10);
    
    ros::Rate rate(10);
    while (ros::ok()) {
        sensor_msgs::JointState msg;
        msg.name = {"joint1"};
        msg.position = {0.5};
        pub.publish(msg);
        rate.sleep(); // Proper sleep heuristic [cite: 73]
    }
    return 0;
}
